# mokito
Package to help standardization of data used in mocks.
